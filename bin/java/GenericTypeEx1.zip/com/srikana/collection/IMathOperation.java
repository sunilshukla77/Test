package com.srikana.collection;

public interface IMathOperation {
	int add(int a, int b);
	int sustract(int a, int b);
}
