package com.collections;

public class Dog extends Animal{

	public Dog() {
		// TODO Auto-generated constructor stub
	}

}
