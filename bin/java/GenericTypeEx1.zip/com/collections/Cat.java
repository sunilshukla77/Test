package com.collections;

public class Cat extends Animal{

	public Cat() {
		// TODO Auto-generated constructor stub
	}

}
