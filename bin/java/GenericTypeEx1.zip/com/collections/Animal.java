package com.collections;

class Animal {

	public Animal() {
		// TODO Auto-generated constructor stub
	}

}
