package com.ravi;

public class InterfaceDemoImpl implements InterfaceDemo{
    @Override
    public int sub(int a, int b) {
        return 0;
    }

    @Override
    public int mul(int a, int b) {
        return 0;
    }

    @Override
    public int add(int a, int b) {
        if (a < 0 && b < 0) return 0;
        return a;
    }
}
