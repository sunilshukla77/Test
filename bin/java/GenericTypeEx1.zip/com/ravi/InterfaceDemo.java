package com.ravi;

interface InterfaceDemo {
    default int add(int a, int b) {
        return a+b;
    }
    int sub(int a, int b);

    int mul(int a, int b);
}
